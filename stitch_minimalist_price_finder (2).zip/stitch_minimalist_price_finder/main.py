from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import List

app = FastAPI(title="Price Comparison API")

# Enable CORS for frontend connection
# This allows the JavaScript fetch() from the frontend to communicate with the backend
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Allow all origins (for development)
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Input schematic
class SearchQuery(BaseModel):
    query: str

# Output schematic (for type hinting and OpenAPI docs)
class ProductOutput(BaseModel):
    platform: str
    name: str
    price: float
    link: str
    is_best_deal: bool

# Predefined dataset
DATASET = [
    {
        "platform": "Amazon",
        "name": "iPhone 15 128GB",
        "price": 79900,
        "link": "https://www.amazon.in/dp/B0CHX1W1XY"
    },
    {
        "platform": "Flipkart",
        "name": "iPhone 15 128GB",
        "price": 78999,
        "link": "https://www.flipkart.com/apple-iphone-15"
    },
    {
        "platform": "Alibaba",
        "name": "iPhone 15 128GB",
        "price": 60000,
        "link": "https://www.alibaba.com/trade/search?SearchText=iphone+15"
    },
    {
        "platform": "Amazon",
        "name": "Samsung Galaxy S24 Ultra",
        "price": 129999,
        "link": "https://www.amazon.in/s?k=samsung+s24+ultra"
    },
    {
        "platform": "Flipkart",
        "name": "Samsung Galaxy S24 Ultra",
        "price": 128000,
        "link": "https://www.flipkart.com/search?q=samsung+s24+ultra"
    },
    {
        "platform": "Amazon",
        "name": "MacBook Air M2 256GB",
        "price": 99900,
        "link": "https://www.amazon.in/s?k=macbook+air+m2"
    },
    {
        "platform": "Croma",
        "name": "MacBook Air M2 256GB",
        "price": 98990,
        "link": "https://www.croma.com/search/?text=macbook+air+m2"
    },
    {
        "platform": "Reliance Digital",
        "name": "MacBook Air M2 256GB",
        "price": 99000,
        "link": "https://www.reliancedigital.in/search?q=macbook+air+m2"
    },
    {
        "platform": "Amazon",
        "name": "Sony WH-1000XM5",
        "price": 29990,
        "link": "https://www.amazon.in/s?k=sony+wh-1000xm5"
    },
    {
        "platform": "Flipkart",
        "name": "Sony WH-1000XM5",
        "price": 28990,
        "link": "https://www.flipkart.com/search?q=sony+wh-1000xm5"
    }
]

def tokenize(text: str) -> set:
    """
    Tokenizes a string into a set of lowercased words.
    
    DSA Rationale: 
    Using Sets provides an O(1) average time complexity for lookups and 
    intersections, which is highly efficient for similarity matching. 
    It also automatically deduplicates tokens.
    """
    return set(text.lower().split())

def find_matches(query: str, dataset: List[dict]) -> List[dict]:
    """
    Finds products that partially or fully match the search query.
    
    DSA Rationale:
    1. Pre-processes the query and dataset Names into hash sets of tokens.
    2. Performs Set Intersection to compute similarity in O(min(len(s1), len(s2))) time.
    3. Filters out items with no common tokens.
    """
    query_tokens = tokenize(query)
    results = []

    for item in dataset:
        name_tokens = tokenize(item["name"])
        
        # Set intersection to find common words
        intersection = query_tokens.intersection(name_tokens)
        
        # Filter: Only include products with at least a partial match
        if len(intersection) > 0:
            score = len(intersection)
            # Create a shallow copy to prevent mutating the original dataset
            match_data = item.copy()
            match_data['_score'] = score
            results.append(match_data)
            
    return results

def sort_and_mark_best_deal(results: List[dict]) -> List[dict]:
    """
    Sorts the results by price and marks the best deal.
    
    DSA Rationale:
    1. Sorting algorithm: Uses Python's built-in Timsort (O(N log N) time complexity), 
       sorting by price ascending.
    2. Modifies the 'is_best_deal' array in a single O(N) pass or O(1) peek if we just
       access the 0th element.
    """
    if not results:
        return []

    # Sort results by price (ascending)
    results.sort(key=lambda x: x["price"])

    # Mark the lowest price as is_best_deal = true (the first element after sorting)
    results[0]["is_best_deal"] = True

    # Note: We still need to give truth values to the rest
    for i in range(1, len(results)):
        results[i]["is_best_deal"] = False

    # Clean up the internal '_score' before returning to the frontend
    for item in results:
        item.pop('_score', None)

    return results

@app.post("/search", response_model=List[ProductOutput])
def search_products(search_param: SearchQuery):
    """
    Main API endpoint to handle the search.
    Expects JSON: {"query": "Search string"}
    Returns: JSON list of matching products, sorted by price.
    """
    query = search_param.query
    
    # Core Logic Step 1 & 2: Tokenize, match, and filter
    matched_results = find_matches(query, DATASET)
    
    # Core Logic Step 3 & 4: Sort and mark best deal
    final_results = sort_and_mark_best_deal(matched_results)
    
    return final_results
