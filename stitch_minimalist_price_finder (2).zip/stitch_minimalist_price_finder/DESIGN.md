---
name: Valence
colors:
  surface: '#f7f9fb'
  surface-dim: '#d8dadc'
  surface-bright: '#f7f9fb'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f2f4f6'
  surface-container: '#eceef0'
  surface-container-high: '#e6e8ea'
  surface-container-highest: '#e0e3e5'
  on-surface: '#191c1e'
  on-surface-variant: '#434655'
  inverse-surface: '#2d3133'
  inverse-on-surface: '#eff1f3'
  outline: '#737686'
  outline-variant: '#c3c6d7'
  surface-tint: '#0053db'
  primary: '#004ac6'
  on-primary: '#ffffff'
  primary-container: '#2563eb'
  on-primary-container: '#eeefff'
  inverse-primary: '#b4c5ff'
  secondary: '#565e74'
  on-secondary: '#ffffff'
  secondary-container: '#dae2fd'
  on-secondary-container: '#5c647a'
  tertiary: '#46566c'
  on-tertiary: '#ffffff'
  tertiary-container: '#5e6e85'
  on-tertiary-container: '#e9f0ff'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#dbe1ff'
  primary-fixed-dim: '#b4c5ff'
  on-primary-fixed: '#00174b'
  on-primary-fixed-variant: '#003ea8'
  secondary-fixed: '#dae2fd'
  secondary-fixed-dim: '#bec6e0'
  on-secondary-fixed: '#131b2e'
  on-secondary-fixed-variant: '#3f465c'
  tertiary-fixed: '#d3e4fe'
  tertiary-fixed-dim: '#b7c8e1'
  on-tertiary-fixed: '#0b1c30'
  on-tertiary-fixed-variant: '#38485d'
  background: '#f7f9fb'
  on-background: '#191c1e'
  surface-variant: '#e0e3e5'
typography:
  display:
    fontFamily: Manrope
    fontSize: 48px
    fontWeight: '800'
    lineHeight: '1.1'
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Manrope
    fontSize: 32px
    fontWeight: '700'
    lineHeight: '1.2'
  headline-md:
    fontFamily: Manrope
    fontSize: 24px
    fontWeight: '600'
    lineHeight: '1.3'
  body-lg:
    fontFamily: Manrope
    fontSize: 18px
    fontWeight: '400'
    lineHeight: '1.6'
  body-md:
    fontFamily: Manrope
    fontSize: 16px
    fontWeight: '400'
    lineHeight: '1.6'
  label-caps:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '600'
    lineHeight: '1.0'
    letterSpacing: 0.05em
  price-display:
    fontFamily: Manrope
    fontSize: 20px
    fontWeight: '700'
    lineHeight: '1.0'
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  container-max: 1200px
  gutter: 24px
  margin-mobile: 16px
  section-padding: 80px
  stack-sm: 8px
  stack-md: 16px
  stack-lg: 32px
---

## Brand & Style
The design system is rooted in **Modern Minimalism** with a focus on utility and clarity. The brand personality is efficient, transparent, and authoritative, designed to instill immediate confidence in users seeking the best value. 

The aesthetic leverages a high-contrast relationship between vast white space and sophisticated dark overlays. By stripping away unnecessary ornamentation, the design system directs all user attention to the data and the primary call-to-action. The emotional response should be one of "effortless precision"—the sense that the tool has already done the hard work of filtering the noise.

## Colors
The palette is built on a foundation of "Cool Neutrals" to maintain a professional, tech-forward atmosphere. 

- **Primary**: A vibrant, high-signal Blue used exclusively for the search action and critical conversion points.
- **Secondary**: A deep Slate-Black used for typography and "Dark Overlays." These overlays are applied to modal backgrounds and tooltips to create a focused, immersive experience.
- **Neutral**: The background utilizes a very light gray (#F8FAFC) to reduce eye strain compared to pure white, while keeping the interface feeling expansive.
- **Accents**: Subtle borders use a light silver to define structure without adding visual weight.

## Typography
This design system employs **Manrope** for its modern, geometric construction that remains highly legible at various weights. Its open counters feel approachable yet systematic. 

**Inter** is used for micro-copy and labels to provide a functional, utilitarian contrast to the more expressive Manrope headlines. Headings should utilize tight letter-spacing and heavy weights to create a sense of importance, while body text maintains generous line height for maximum readability during price comparisons.

## Layout & Spacing
The layout follows a **Fixed Grid** philosophy centered on a 1200px max-width container. This ensures that on large screens, the price comparison data remains in the primary field of vision without excessive eye travel. 

The rhythm is dictated by an 8px base unit. Section vertical spacing is generous (80px+) to allow the "minimalist" aesthetic to breathe. Use a 12-column grid for product listings, typically spanning 3 columns per card on desktop (4 per row) or 4 columns (3 per row) for detailed comparison views.

## Elevation & Depth
This design system uses **Ambient Shadows** to create a soft, natural sense of depth. Instead of harsh borders, elevation is used to distinguish the search bar and product cards from the background.

- **Level 1 (Cards):** Very soft, wide-spread shadow (0px 4px 20px rgba(0,0,0,0.03)) to lift cards slightly from the light gray background.
- **Level 2 (Search Bar):** Focused, medium-diffusion shadow (0px 10px 30px rgba(0,0,0,0.08)) to make the primary tool feel "tactile" and interactive.
- **Overlays:** Dark overlays should use 60% opacity of the Secondary color with a subtle backdrop blur (4px) to keep the user focused on the active task.

## Shapes
The shape language is consistently **Rounded**. A 0.5rem (8px) radius is the standard for cards and inputs, providing a friendly and modern feel that avoids the "corporate coldness" of sharp corners. 

The search bar and primary action buttons utilize a `rounded-xl` or `rounded-full` (pill) treatment to signify their priority and ease of use. This contrast in radius helps the search component stand out as the primary functional element.

## Components
- **Search Bar**: A prominent, pill-shaped input with a generous internal horizontal padding (24px). It includes a magnifying glass icon and the primary blue button nested within the right side of the container.
- **Buttons**: Primary buttons feature a subtle lift on hover (transform: translateY(-2px)) and a brightness increase. Secondary buttons should be ghost-style with a light border.
- **Product Cards**: Minimalist containers with no visible borders; depth is defined solely by Level 1 shadows. Price information is emphasized with `price-display` typography.
- **Comparison Chips**: Small, rounded badges used to highlight "Best Value" or "Cheapest," utilizing low-saturation background tints of the primary color.
- **Inputs**: Field focus is indicated by a 2px solid primary blue border, with the inner shadow removed to flatten the element on interaction.
- **Price Toggles**: Horizontal switch components to toggle between "Monthly" and "Yearly" or different currencies, using a smooth sliding animation for the active state.